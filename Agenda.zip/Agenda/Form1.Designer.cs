﻿
namespace Agenda
{
    partial class frmMain
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAdicionarContato = new System.Windows.Forms.Button();
            this.btnApagarContato = new System.Windows.Forms.Button();
            this.tPesquisar = new System.Windows.Forms.TextBox();
            this.lbTitulo = new System.Windows.Forms.Label();
            this.dataGrid = new System.Windows.Forms.DataGridView();
            this.tNome = new System.Windows.Forms.TextBox();
            this.tTelefone = new System.Windows.Forms.TextBox();
            this.tEmail = new System.Windows.Forms.TextBox();
            this.tDataNasc = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAdicionarContato
            // 
            this.btnAdicionarContato.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnAdicionarContato.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdicionarContato.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnAdicionarContato.Location = new System.Drawing.Point(80, 272);
            this.btnAdicionarContato.Name = "btnAdicionarContato";
            this.btnAdicionarContato.Size = new System.Drawing.Size(195, 38);
            this.btnAdicionarContato.TabIndex = 0;
            this.btnAdicionarContato.Text = "Adicionar Contato";
            this.btnAdicionarContato.UseVisualStyleBackColor = false;
            this.btnAdicionarContato.Click += new System.EventHandler(this.btnAdicionarContato_Click);
            // 
            // btnApagarContato
            // 
            this.btnApagarContato.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnApagarContato.Enabled = false;
            this.btnApagarContato.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnApagarContato.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnApagarContato.Location = new System.Drawing.Point(80, 316);
            this.btnApagarContato.Name = "btnApagarContato";
            this.btnApagarContato.Size = new System.Drawing.Size(195, 37);
            this.btnApagarContato.TabIndex = 1;
            this.btnApagarContato.Text = "Apagar Contatos";
            this.btnApagarContato.UseVisualStyleBackColor = false;
            this.btnApagarContato.Click += new System.EventHandler(this.btnApagarContato_Click);
            // 
            // tPesquisar
            // 
            this.tPesquisar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tPesquisar.ForeColor = System.Drawing.Color.LightGray;
            this.tPesquisar.Location = new System.Drawing.Point(32, 67);
            this.tPesquisar.MinimumSize = new System.Drawing.Size(4, 20);
            this.tPesquisar.Name = "tPesquisar";
            this.tPesquisar.Size = new System.Drawing.Size(300, 21);
            this.tPesquisar.TabIndex = 2;
            this.tPesquisar.Text = "Pesquisar Contatos";
            this.tPesquisar.Enter += new System.EventHandler(this.tPesquisar_Enter);
            this.tPesquisar.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tPesquisar_KeyDown);
            this.tPesquisar.Leave += new System.EventHandler(this.tPesquisar_Leave);
            // 
            // lbTitulo
            // 
            this.lbTitulo.AutoSize = true;
            this.lbTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTitulo.Location = new System.Drawing.Point(32, 10);
            this.lbTitulo.Name = "lbTitulo";
            this.lbTitulo.Size = new System.Drawing.Size(305, 36);
            this.lbTitulo.TabIndex = 3;
            this.lbTitulo.Text = "Agenda de Contatos";
            // 
            // dataGrid
            // 
            this.dataGrid.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.dataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGrid.Location = new System.Drawing.Point(361, 10);
            this.dataGrid.Name = "dataGrid";
            this.dataGrid.Size = new System.Drawing.Size(427, 349);
            this.dataGrid.TabIndex = 4;
            this.dataGrid.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGrid_RowHeaderMouseClick);
            this.dataGrid.MouseLeave += new System.EventHandler(this.dataGrid_MouseLeave);
            // 
            // tNome
            // 
            this.tNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tNome.ForeColor = System.Drawing.Color.LightGray;
            this.tNome.Location = new System.Drawing.Point(53, 131);
            this.tNome.MaxLength = 50;
            this.tNome.MinimumSize = new System.Drawing.Size(4, 20);
            this.tNome.Name = "tNome";
            this.tNome.Size = new System.Drawing.Size(250, 21);
            this.tNome.TabIndex = 5;
            this.tNome.Text = "Nome";
            this.tNome.Enter += new System.EventHandler(this.tNome_Enter);
            this.tNome.Leave += new System.EventHandler(this.tNome_Leave);
            // 
            // tTelefone
            // 
            this.tTelefone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tTelefone.ForeColor = System.Drawing.Color.LightGray;
            this.tTelefone.Location = new System.Drawing.Point(53, 162);
            this.tTelefone.MaxLength = 11;
            this.tTelefone.MinimumSize = new System.Drawing.Size(4, 20);
            this.tTelefone.Name = "tTelefone";
            this.tTelefone.Size = new System.Drawing.Size(250, 21);
            this.tTelefone.TabIndex = 6;
            this.tTelefone.Text = "Telefone";
            this.tTelefone.Enter += new System.EventHandler(this.tTelefone_Enter);
            this.tTelefone.Leave += new System.EventHandler(this.tTelefone_Leave);
            // 
            // tEmail
            // 
            this.tEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tEmail.ForeColor = System.Drawing.Color.LightGray;
            this.tEmail.Location = new System.Drawing.Point(53, 224);
            this.tEmail.MaxLength = 100;
            this.tEmail.MinimumSize = new System.Drawing.Size(4, 20);
            this.tEmail.Name = "tEmail";
            this.tEmail.Size = new System.Drawing.Size(250, 21);
            this.tEmail.TabIndex = 8;
            this.tEmail.Text = "E-mail";
            this.tEmail.Enter += new System.EventHandler(this.tEmail_Enter);
            this.tEmail.Leave += new System.EventHandler(this.tEmail_Leave);
            // 
            // tDataNasc
            // 
            this.tDataNasc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tDataNasc.ForeColor = System.Drawing.Color.LightGray;
            this.tDataNasc.Location = new System.Drawing.Point(53, 193);
            this.tDataNasc.MaxLength = 8;
            this.tDataNasc.MinimumSize = new System.Drawing.Size(4, 20);
            this.tDataNasc.Name = "tDataNasc";
            this.tDataNasc.Size = new System.Drawing.Size(250, 21);
            this.tDataNasc.TabIndex = 7;
            this.tDataNasc.Text = "Data de Nascimento";
            this.tDataNasc.Enter += new System.EventHandler(this.tDataNasc_Enter);
            this.tDataNasc.Leave += new System.EventHandler(this.tDataNasc_Leave);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 371);
            this.Controls.Add(this.tDataNasc);
            this.Controls.Add(this.tEmail);
            this.Controls.Add(this.tTelefone);
            this.Controls.Add(this.tNome);
            this.Controls.Add(this.dataGrid);
            this.Controls.Add(this.lbTitulo);
            this.Controls.Add(this.tPesquisar);
            this.Controls.Add(this.btnApagarContato);
            this.Controls.Add(this.btnAdicionarContato);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(816, 410);
            this.MinimumSize = new System.Drawing.Size(816, 410);
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Agenda";
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAdicionarContato;
        private System.Windows.Forms.Button btnApagarContato;
        private System.Windows.Forms.TextBox tPesquisar;
        private System.Windows.Forms.Label lbTitulo;
        private System.Windows.Forms.DataGridView dataGrid;
        private System.Windows.Forms.TextBox tNome;
        private System.Windows.Forms.TextBox tTelefone;
        private System.Windows.Forms.TextBox tEmail;
        private System.Windows.Forms.TextBox tDataNasc;
    }
}

