﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Agenda
{
    public partial class frmMain : Form
    {
        MySqlConnection conexao;
        MySqlCommand comando;
        MySqlDataAdapter adapter;
        string lSql;

        int id, idade, totalContatos;

        public frmMain()
        {
            InitializeComponent();

            //Cria a conexão com o banco
            conexao = new MySqlConnection("Server=localhost;Database=agenda;Uid=root;Pwd=root;");
            comando = null;

            atualizarGrid();
        }

        #region TextBox_Enter
        private void tPesquisar_Enter(object sender, EventArgs e)
        {
            if (tPesquisar.Text == "Pesquisar Contatos ( " + totalContatos + " )" || tPesquisar.Text == "")
            {
                tPesquisar.Text = "";
                tPesquisar.ForeColor = Color.Black;
            }
        }

        private void tNome_Enter(object sender, EventArgs e)
        {
            if (tNome.Text == "Nome" || tNome.Text == "")
            {
                tNome.Text = "";
                tNome.ForeColor = Color.Black;
            }
        }

        private void tTelefone_Enter(object sender, EventArgs e)
        {
            if (tTelefone.Text == "Telefone" || tTelefone.Text == "")
            {
                tTelefone.Text = "";
                tTelefone.ForeColor = Color.Black;
            }
        }

        private void tDataNasc_Enter(object sender, EventArgs e)
        {
            if (tDataNasc.Text == "Data de Nascimento" || tDataNasc.Text == "")
            {
                tDataNasc.Text = "";
                tDataNasc.ForeColor = Color.Black;
            }
        }

        private void tEmail_Enter(object sender, EventArgs e)
        {
            if (tEmail.Text == "E-mail" || tEmail.Text == "")
            {
                tEmail.Text = "";
                tEmail.ForeColor = Color.Black;
            }
        }
        #endregion

        #region TextBox_Leave
        private void tPesquisar_Leave(object sender, EventArgs e)
        {
            if (tPesquisar.Text == "")
            {
                tPesquisar.Text = "Pesquisar Contatos ( " + totalContatos + " )";
                tPesquisar.ForeColor = Color.LightGray;
            }
        }

        private void tNome_Leave(object sender, EventArgs e)
        {
            if (tNome.Text == "")
            {
                tNome.Text = "Nome";
                tNome.ForeColor = Color.LightGray;
            }
        }

        private void tTelefone_Leave(object sender, EventArgs e)
        {
            if (tTelefone.Text == "")
            {
                tTelefone.Text = "Telefone";
                tTelefone.ForeColor = Color.LightGray;
            } else
            {
                if (tTelefone.Text.Length == 11)
                {
                    string novo = Mask(tTelefone.Text, "## #####-####");
                    tTelefone.Text = novo;
                } 
                else if (tTelefone.Text.Length < 11)
                {
                    MessageBox.Show("Número de telefone incorreto! Favor digitar somente números e o inserir o código de área, Ex: '48988887777' ");
                    tTelefone.Text = "Telefone";
                    tTelefone.ForeColor = Color.LightGray;
                }
            }
        }

        private void tDataNasc_Leave(object sender, EventArgs e)
        {
            if (tDataNasc.Text == "")
            {
                tDataNasc.Text = "Data de Nascimento";
                tDataNasc.ForeColor = Color.LightGray;
            } else
            {
                if (tDataNasc.Text.Length == 8)
                {
                    string novo = Mask(tDataNasc.Text, "##/##/####");
                    tDataNasc.Text = novo;
                }
                else if (tDataNasc.Text.Length < 8)
                {
                    MessageBox.Show("Data incorreta! Favor digitar somente números no padrão 'DDMMYYYY', Ex: '01012001' ");
                    tDataNasc.Text = "Data de Nascimento";
                    tDataNasc.ForeColor = Color.LightGray;
                }
            }
        }

        private void tEmail_Leave(object sender, EventArgs e)
        {
            if (tEmail.Text == "")
            {
                tEmail.Text = "E-mail";
                tEmail.ForeColor = Color.LightGray;
            }
        }

        #endregion

        private void btnAdicionarContato_Click(object sender, EventArgs e)
        {
            // ----- Validação ------
            string lsInicio = "Os seguintes campos estão incorretos ou vazios: \n", 
                   lsMessage = "";

            if (tNome.Text == "" || tNome.Text == "Nome")
                lsMessage += "Nome,";

            if (tTelefone.Text == "" || tTelefone.Text == "Telefone")
                lsMessage += " Telefone,";

            if (tDataNasc.Text == "" || tDataNasc.Text == "Data de Nascimento")
                lsMessage += " Data de Nascimento,";

            if (tEmail.Text == "" || tEmail.Text == "E-mail")
                lsMessage += " E-mail,";

            if (lsMessage != "")
            {
                lsMessage = lsMessage.Remove(lsMessage.Length -1);
                lsMessage = lsMessage.Insert(lsMessage.Length, ".");
                MessageBox.Show(lsInicio + lsMessage);
                return;
            }

            // ----- Invertendo data para gravar no banco ------
            tDataNasc.Text = tDataNasc.Text.Replace("/", "");
            char[] charArray = tDataNasc.Text.ToCharArray();
            string dataInvertida = "";
            dataInvertida =  charArray[4].ToString();
            dataInvertida += charArray[5].ToString();
            dataInvertida += charArray[6].ToString();
            dataInvertida += charArray[7].ToString();
            dataInvertida += charArray[2].ToString();
            dataInvertida += charArray[3].ToString();
            dataInvertida += charArray[0].ToString();
            dataInvertida += charArray[1].ToString();
            dataInvertida = Mask(dataInvertida, "####-##-##");

            // ----- Calculando idade do contato -----
            string novaData = tDataNasc.Text.Insert(2, "-");
            novaData = novaData.Insert(5, "-");
            DateTime data = DateTime.ParseExact(novaData, "dd-mm-yyyy", System.Globalization.CultureInfo.InvariantCulture);
            idade = DateTime.Now.Subtract(data).Days;
            idade = idade / 365;

            // ----- Gravando contato no banco -----
            try
            {
                lSql = "INSERT INTO contatos (nome, telefone, idade, dt_nasc, email) " +
                       "VALUES (\"" +tNome.Text+ "\", \"" +tTelefone.Text+ "\", \"" +idade.ToString()+ "\", \'" +dataInvertida+ "\', \"" +tEmail.Text+ "\")";

                comando = new MySqlCommand(lSql, conexao);
                conexao.Open();
                comando.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                tNome.Text          = "Nome";
                tNome.ForeColor     = Color.LightGray;
                tTelefone.Text      = "Telefone";
                tTelefone.ForeColor = Color.LightGray;
                tDataNasc.Text      = "Data de Nascimento";
                tDataNasc.ForeColor = Color.LightGray;
                tEmail.Text         = "E-mail";
                tEmail.ForeColor    = Color.LightGray;

                atualizarGrid();

                comando = null;
            }
        }

        #region Apagar Contato
        private void dataGrid_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            btnApagarContato.Enabled = true;
            try
            {
                id = Convert.ToInt32(dataGrid.Rows[dataGrid.CurrentRow.Index].Cells[0].Value);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Não foi possível selecionar o contato. \nErro: " + ex.Message);
                btnApagarContato.Enabled = false;
                return;
            }
        }
        private void dataGrid_MouseLeave(object sender, EventArgs e)
        {
            if (dataGrid.SelectedRows.Count == 0)
            {
                btnApagarContato.Enabled = false;
            }
        }

        private void btnApagarContato_Click(object sender, EventArgs e)
        {
            try
            {
                lSql = "DELETE FROM contatos WHERE cd_contato = " + id.ToString();

                comando = new MySqlCommand(lSql, conexao);
                conexao.Open();
                comando.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                btnApagarContato.Enabled = false;
                atualizarGrid();
                conexao.Close();
            }
        }
        #endregion

        private void tPesquisar_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                try
                {
                    lSql = "SELECT cd_contato AS Id,   " +
                                "nome AS Nome,         " +
                                "telefone AS Telefone, " +
                                "idade AS Idade,       " +
                                "DATE_FORMAT(dt_nasc,'%d/%m/%Y') AS \"Data Nasc.\", " +
                                "email AS \"E-mail\"   " +
                           "FROM contatos WHERE nome like \"%"+tPesquisar.Text+"%\"";

                    DataTable table = new DataTable();
                    adapter = new MySqlDataAdapter(lSql, conexao);
                    adapter.Fill(table);
                    dataGrid.DataSource = table;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    conexao.Close();
                }
            }
        }

        private string Mask(string minhaString, string mask)
        {
            int lIndex = 0;
            foreach (char lChar in mask)
            {
                if(lChar != '#')
                {
                    minhaString = minhaString.Insert(lIndex, lChar.ToString());
                }
                lIndex++;
            }
            return minhaString;
        }

        private void atualizarGrid()
        {
            try
            {
                lSql = "SELECT cd_contato AS Id,   "+
                            "nome AS Nome,         "+
                            "telefone AS Telefone, "+
                            "idade AS Idade,       "+ 
                            "DATE_FORMAT(dt_nasc,'%d/%m/%Y') AS \"Data Nasc.\", "+
                            "email AS \"E-mail\"   "+
                       "FROM contatos";

                DataTable table = new DataTable();
                adapter = new MySqlDataAdapter(lSql, conexao);
                adapter.Fill(table);
                dataGrid.DataSource = table;

                totalContatos = table.Rows.Count;
                tPesquisar.Text = "Pesquisar Contatos ( " + totalContatos + " )";
                tPesquisar.ForeColor = Color.LightGray;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexao.Close();
            }
        }

    }
}
